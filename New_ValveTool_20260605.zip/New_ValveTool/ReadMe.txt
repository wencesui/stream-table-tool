New Valve Tag Tool (2026-06-05):

1. Replace old cells with new cells that contains tags

2. Place actuator on a manual valve interactively by two data points (location and direction)
	2.1 Once placed, the tag number is changed to "AV", and OPERATIONTYPE tag valve becomes "Automatic Valve"
	2.2 If an actuator is deleted, the "AV" will be changed back to original manual vale type, and OPERATIONTYPE tag valve becomes "Manual Valve"
	
3. Export
	3.1 Valve data is exported to Valve List.
	3.2 Fraction becomes symbol. For example, 3/4" ==> ¾

4. Import
	4.1 Tag number and other data updates in PID.  Keep using symbol for fractions.
	4.2 If an existing "Actuator Type" is changed for an automatic valve, the actuator cell will be changed accordingly.
	4.3 If a new "Actuator Type" is added for a manual valve, the actuator cell will be added accordingly.
	4.4 If an existing "Actuator Type" is deleted, the existing actuator cell is deleted in PID.
	4.5 If a manual valve type is changed, for example, from Ball Valve to Gate Valve, the manual valve cell is changed accordingly. Hence the element Id is changed in the list.
